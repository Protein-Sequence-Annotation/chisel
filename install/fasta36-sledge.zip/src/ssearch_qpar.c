/* ssearch_qpar.c - query-parallel ssearch36 driver for Sledge */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <math.h>

#include "defs.h"
#include "structs.h"
#include "param.h"
#include "best_stats.h"
#include "rstruct.h"
#include "thr_buf_structs.h"
#include "mm_file.h"
#include "drop_func.h"
#include "ssearch_qpar.h"

#define QPAR_AG_STATS 3

/* mirror scaleswn.c for per-pair Karlin-Altschul stats */
struct ag_stat_str {
  double K, Lambda, H, a_n0f, a_n0;
};

struct pstat_str {
  int zsflag;
  double ngLambda, ngK, ngH;
  double ave_n1;
  double sample_fract;
  double zs_off;
  union {
    struct ag_stat_str ag;
  } r_u;
};

extern int fa_max_workers;

extern int ag_parm(char *pam_name, int gdelval, int ggapval, struct pstat_str *pu);
extern double find_z(int score, double escore, int length, double comp,
                     struct pstat_str *pu);
extern double zs_to_E(double zs, int n1, int dnaseq, long entries, struct db_str db);
extern double zs_to_bit(double zs, int n0, int n1);

extern struct seqr_chain *next_seqr_chain(const struct mng_thr *m_bufi_p,
                                          struct getlib_str *getlib_info,
                                          struct buf_head *lib_bhead_p,
                                          struct mngmsg *m_msp,
                                          const struct pstruct *ppst);

#ifdef COMP_MLIB
#define QGETLIB(f) ((f)->getlib)
#endif

struct qpar_pool {
  struct mngmsg *m_msg;
  struct pstruct *pst;
  struct lmf_str *q_file_p;
  struct qpar_lib_entry *lib;
  int n_lib;
  struct db_str db;
  FILE *outfd;
  pthread_mutex_t query_mtx;
  pthread_mutex_t out_mtx;
  int done;
};

static void
qpar_first_id(char *dest, int dest_len, const char *src)
{
  char *bp;
  int i, nf;
  char tmp[MAX_SSTR];
  char *fields[8];

  if (src == NULL || src[0] == '\0') {
    dest[0] = '\0';
    return;
  }
  strncpy(dest, src, dest_len - 1);
  dest[dest_len - 1] = '\0';
  if ((bp = strpbrk(dest, " \t")) != NULL) *bp = '\0';
  if (strlen(dest) >= 3 && dest[2] == '|') {
    strncpy(tmp, dest, sizeof(tmp) - 1);
    tmp[sizeof(tmp) - 1] = '\0';
    nf = 0;
    fields[nf] = tmp;
    for (i = 0; tmp[i] != '\0' && nf < 7; i++) {
      if (tmp[i] == '|') {
        tmp[i] = '\0';
        fields[++nf] = tmp + i + 1;
      }
    }
    nf++;
    if (nf >= 2) {
      strncpy(dest, fields[1], dest_len - 1);
      dest[dest_len - 1] = '\0';
    }
  }
}

static void
qpar_init_pstat(int n0, struct pstruct *ppst, struct pstat_str *pu)
{
  int t_gdelval, t_ggapval;

  memset(pu, 0, sizeof(struct pstat_str));
#ifdef OLD_FASTA_GAP
  t_gdelval = ppst->gdelval;
  t_ggapval = ppst->ggapval;
#else
  t_gdelval = ppst->gdelval + ppst->ggapval;
  t_ggapval = ppst->ggapval;
#endif
  if (!ag_parm(ppst->pam_name, t_gdelval, t_ggapval, pu)) {
    ag_parm("BL62", t_gdelval, t_ggapval, pu);
  }
  pu->r_u.ag.a_n0 = (double)n0;
  pu->r_u.ag.a_n0f = log(pu->r_u.ag.K * pu->r_u.ag.a_n0) / pu->r_u.ag.H;
  pu->zsflag = QPAR_AG_STATS;
}

static void
qpar_emit_hit(struct qpar_pool *pool, const char *qid, const char *sid,
              int n0, int n1, double eval, double bits)
{
  if (pool->outfd == NULL) return;
  pthread_mutex_lock(&pool->out_mtx);
  fprintf(pool->outfd,
          "%s\t%s\t0\t0\t0\t0\t1\t%d\t1\t%d\t%.3g\t%.1f\n",
          qid, sid, n0, n1, eval, bits);
  pthread_mutex_unlock(&pool->out_mtx);
}

static void
qpar_scan_one_query(unsigned char *aa0, int n0, const char *qtitle,
                    struct qpar_pool *pool, void **f_str)
{
  struct pstruct *ppst = pool->pst;
  struct mngmsg *m_msg = pool->m_msg;
  struct pstat_str pstat;
  struct rstruct rst;
  struct score_count_s s_info;
  char qid[MAX_SSTR];
  char sid[MAX_SSTR];
  int i, score;
  double zscore, eval, bits;
  int early;

  if (n0 <= 0) return;

  qpar_first_id(qid, sizeof(qid), qtitle);
  ppst->n0 = n0;
  qpar_init_pstat(n0, ppst, &pstat);
  init_work(aa0, n0, ppst, f_str);

  early = m_msg->early_stop && !m_msg->all_hits;
  memset(&s_info, 0, sizeof(s_info));

  for (i = 0; i < pool->n_lib; i++) {
    struct seq_record *seq = pool->lib[i].seq;
    struct mseq_record *mseq = pool->lib[i].mseq;

    if (seq->n1 < ppst->n1_low || seq->n1 > ppst->n1_high) continue;

    do_work(aa0, n0, seq->aa1b, seq->n1, 0, ppst, *f_str,
            0, 0, &rst, &s_info);

    score = rst.score[0];
    if (score <= 0) continue;

    zscore = find_z(score, 0.0, seq->n1, rst.comp, &pstat);
    eval = zs_to_E(zscore, seq->n1, ppst->dnaseq, ppst->zdb_size, pool->db);
    if (eval > m_msg->e_cut) continue;

    qpar_first_id(sid, sizeof(sid),
                  (mseq->libstr[0] != '\0') ? mseq->libstr :
                  (mseq->bline ? mseq->bline : ""));
    bits = zs_to_bit(zscore, n0, seq->n1);
    qpar_emit_hit(pool, qid, sid, n0, seq->n1, eval, bits);

    if (early) break;
  }
}

static void *
qpar_worker(void *arg)
{
  struct qpar_pool *pool = (struct qpar_pool *)arg;
  struct mngmsg *m_msg = pool->m_msg;
  unsigned char *aa0;
  char qtitle[MAX_STR];
  long qseek;
  int qlcont, n0;
  void *f_str = NULL;

  aa0 = (unsigned char *)malloc((MAXTST + 1 + SEQ_PAD) * sizeof(unsigned char));
  if (aa0 == NULL) {
    fprintf(stderr, "*** ERROR [%s:%d] qpar_worker: cannot allocate query buffer\n",
            __FILE__, __LINE__);
    return NULL;
  }
  aa0++;

  for (;;) {
    pthread_mutex_lock(&pool->query_mtx);
    if (pool->done) {
      pthread_mutex_unlock(&pool->query_mtx);
      break;
    }
    n0 = QGETLIB(pool->q_file_p)(aa0, MAXTST, qtitle, sizeof(qtitle), &qseek, &qlcont,
                 pool->q_file_p, &m_msg->q_off);
    if (n0 <= 0) {
      pool->done = 1;
      pthread_mutex_unlock(&pool->query_mtx);
      break;
    }
    pthread_mutex_unlock(&pool->query_mtx);

    if (strchr(qtitle, ' ') != NULL) *strchr(qtitle, ' ') = '\0';
    qpar_scan_one_query(aa0, n0, qtitle, pool, &f_str);
  }

  free(--aa0);
  return NULL;
}

static int
qpar_build_lib_index(struct getlib_str *getlib_info,
                     struct qpar_lib_entry **lib_out, int *n_out)
{
  struct seqr_chain *chain;
  struct qpar_lib_entry *arr;
  int count = 0, cap = 4096, i;

  *lib_out = NULL;
  *n_out = 0;
  if (getlib_info->start_seqr_chain == NULL) return 0;

  arr = (struct qpar_lib_entry *)malloc((size_t)cap * sizeof(struct qpar_lib_entry));
  if (arr == NULL) return -1;

  for (chain = getlib_info->start_seqr_chain; chain != NULL; chain = chain->next) {
    for (i = 0; i < chain->cur_seq_cnt; i++) {
      if (count >= cap) {
        cap *= 2;
        arr = (struct qpar_lib_entry *)realloc(arr,
               (size_t)cap * sizeof(struct qpar_lib_entry));
        if (arr == NULL) return -1;
      }
      arr[count].seq = &chain->seqr_base[i];
      arr[count].mseq = &chain->mseqr_base[i];
      count++;
    }
  }

  *lib_out = arr;
  *n_out = count;
  return 0;
}

static void
qpar_preload_library(const struct mng_thr *m_bufi_p, struct getlib_str *getlib_info,
                     struct mngmsg *m_msg, struct pstruct *ppst)
{
  struct buf_head bh;

  memset(&bh, 0, sizeof(bh));
  getlib_info->cur_seqr_chain = getlib_info->start_seqr_chain;
  getlib_info->eof = 0;
  getlib_info->use_memory = 0;

  while (next_seqr_chain(m_bufi_p, getlib_info, &bh, m_msg, ppst) != NULL) {
    /* read library into memory */
  }
  getlib_info->cur_seqr_chain = getlib_info->start_seqr_chain;
  if (getlib_info->use_memory <= 0) getlib_info->use_memory = 1;
}

void
qpar_run_search(struct mngmsg *m_msg, struct pstruct *pst,
                struct lmf_str *q_file_p, struct getlib_str *getlib_info,
                const struct mng_thr *m_bufi_p,
                unsigned char **aa0, struct db_str *qtt, int *qlib,
                FILE *outfd,
                unsigned char *first_aa0, int first_n0,
                const char *first_qtitle)
{
  struct qpar_pool pool;
  pthread_t *threads;
  void *main_f_str = NULL;
  char qtitle_buf[MAX_STR];
  int i, nthreads;

  (void)aa0;

  qpar_preload_library(m_bufi_p, getlib_info, m_msg, pst);

  if (qpar_build_lib_index(getlib_info, &pool.lib, &pool.n_lib) != 0) {
    fprintf(stderr, "*** ERROR [%s:%d] qpar_build_lib_index failed\n", __FILE__, __LINE__);
    exit(1);
  }

  if (!pst->zdb_size_set) {
    pst->zdb_size = pool.n_lib;
  }

  pool.m_msg = m_msg;
  pool.pst = pst;
  pool.q_file_p = q_file_p;
  pool.outfd = outfd;
  pool.db.entries = pool.n_lib;
  pool.db.length = m_msg->ldb.length;
  pool.db.carry = 0;
  pool.done = 0;
  pthread_mutex_init(&pool.query_mtx, NULL);
  pthread_mutex_init(&pool.out_mtx, NULL);

  if (first_n0 > 0 && first_aa0 != NULL && first_qtitle != NULL) {
    strncpy(qtitle_buf, first_qtitle, sizeof(qtitle_buf) - 1);
    qtitle_buf[sizeof(qtitle_buf) - 1] = '\0';
    qpar_scan_one_query(first_aa0, first_n0, qtitle_buf, &pool, &main_f_str);
    qtt->entries++;
    qtt->length += first_n0;
  }

  nthreads = fa_max_workers;
  if (nthreads < 1) nthreads = 1;

  threads = (pthread_t *)calloc((size_t)nthreads, sizeof(pthread_t));
  if (threads == NULL) {
    fprintf(stderr, "*** ERROR [%s:%d] cannot allocate thread array\n", __FILE__, __LINE__);
    exit(1);
  }

  for (i = 0; i < nthreads; i++) {
    if (pthread_create(&threads[i], NULL, qpar_worker, &pool) != 0) {
      fprintf(stderr, "*** ERROR [%s:%d] pthread_create failed\n", __FILE__, __LINE__);
      exit(1);
    }
  }

  for (i = 0; i < nthreads; i++) {
    pthread_join(threads[i], NULL);
  }

  (*qlib)++;

  free(threads);
  free(pool.lib);
  pthread_mutex_destroy(&pool.query_mtx);
  pthread_mutex_destroy(&pool.out_mtx);
}
