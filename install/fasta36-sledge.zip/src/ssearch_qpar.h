/* ssearch_qpar.h - query-parallel Smith-Waterman search (Sledge fork) */

#ifndef SSEARCH_QPAR_H
#define SSEARCH_QPAR_H

#include <stdio.h>

struct mngmsg;
struct pstruct;
struct lmf_str;
struct getlib_str;
struct mng_thr;
struct db_str;
struct seq_record;
struct mseq_record;

struct qpar_lib_entry {
  struct seq_record *seq;
  struct mseq_record *mseq;
};

void qpar_run_search(struct mngmsg *m_msg, struct pstruct *pst,
                     struct lmf_str *q_file_p, struct getlib_str *getlib_info,
                     const struct mng_thr *m_bufi_p,
                     unsigned char **aa0, struct db_str *qtt, int *qlib,
                     FILE *outfd,
                     unsigned char *first_aa0, int first_n0,
                     const char *first_qtitle);

#endif /* SSEARCH_QPAR_H */
