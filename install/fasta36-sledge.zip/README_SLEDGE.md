# fasta36 — Sledge query-parallel ssearch36

Sledge's bundled FASTA36 `ssearch36` with query-parallel search and chisel-oriented defaults.

## Features

- **Query parallelism** (`-T N`): worker threads each take the next query and scan the full in-memory library. Target parallelism is disabled.
- **Early stopping** (`-X early_stop`): stop scanning the library after the first hit at or below `-E` (pass 1 / chisel pruning).
- **All hits** (`-X all_hits`): report every hit below `-E` (pass 2).
- **Karlin–Altschul stats** (`-z 3`, default): per-pair E-values using matrix/gap parameters.
- **BLOSUM62 default** (`-s BL62`): overridden only if `-s` is supplied.

## Build (Linux x86_64 SSE2)

```bash
cd src
make -f ../make/Makefile.linux64_sse2 ssearch36
```

Binary: `bin/ssearch36`

## Recommended chisel / Sledge flags

```bash
ssearch36 -m 8 -q -T $SW_CORES -E $E_VALUE -Z $Z_SIZE \
  -s BL62 -z 3 -f -11 -g -1 -X early_stop  query.fasta library.fasta   # pass 1
ssearch36 -m 8 -q -T $SW_CORES -E $E_VALUE -Z $Z_SIZE \
  -s BL62 -z 3 -f -11 -g -1 -X all_hits   query.fasta library.fasta   # pass 2
```

Gap open/extend `-f -11 -g -1` match HMMER3/phmmer defaults for BLOSUM62.

## E-value comparability to phmmer

Both use Karlin–Altschul with BLOSUM62 and the same database size (`-Z`), so E-values are in the same family. They will not be identical because:

- phmmer uses an HMM profile and its own pipeline; ssearch uses Smith–Waterman on raw sequences.
- FASTA m8 output from this fork omits alignment columns (chisel only needs query/target IDs).

For closest agreement, use `-s BL62 -z 3 -f -11 -g -1 -Z <same as phmmer>`.

## Implementation notes

- `SLEDGE_QPAR` in `comp_mqpar9.o`, `ssearch_qpar.o`, `init_sw_sse.o`
- Library preloaded once; queries distributed via mutex-protected `QGETLIB`
- Compile flag `-DSLEDGE_QPAR` gates all changes
- SW shard query files use short `/tmp/chisel_sw.*` paths (chisel_p3) because `MAX_FN` is 120
